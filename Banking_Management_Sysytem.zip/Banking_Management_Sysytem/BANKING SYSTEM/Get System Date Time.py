import datetime
d = datetime.datetime.now()
dt = d.strftime("%Y-%m-%d %H:%M:%S")
print(dt)
